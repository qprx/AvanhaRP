Guide til .env fil

Det er vigtigt du laver en .env fil roden af projektet

Som skal indeholde følgende:
DOMAIN=http://localhost:3000
SESSION_SECRET=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789
STEAM_API_KEY=Din steam api key her




DATABASE_URL="postgresql://neondb_owner:dovgxX2NPVn1@ep-billowing-truth-a2dy2t8t-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require"
